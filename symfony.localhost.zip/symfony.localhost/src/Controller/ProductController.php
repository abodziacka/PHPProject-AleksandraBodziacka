<?php

namespace App\Controller;

use App\Entity\Products;

class ProductController extends AbstractController
{
    /**
     * @Route("/product", name="product")
     */
    public function index()
    {
        $products = $this->getDoctrine()->getRepository(Products::class)->findAll();

        return $this->render('product/index.html.twig', [
            'controller_name' => 'ProductController',
        ]);
    }

    /**
     * @Route("/product", name="create_product")
     */
    public function createProduct(): Response
    {
        $entityManager = $this->getDoctrine()->getManager();

        $product = new Products();

        $product->setName("Guitar");
        $product->setPrice(600);
        $product->setCategory("Music");
        $product->setQuantity(12);
        $product->setSoldOut(false);
        $product->setCurrency("pln");
        $product->setDiscount(true);
        $product->setDiscountPercent(0.5);
        $product->setPriceAfterDiscount(300);
        $product->setDescription('Make a beautiful sound!');


        $entityManager->persist($product);

        $entityManager->flush();

        return new Response('Saved new product with id '.$product->getId());
    }
}
