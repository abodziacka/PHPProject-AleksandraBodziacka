<?php

namespace App\Entity;

use App\Repository\ProductsRepository;
use Doctrine\ORM\Mapping as ORM;

/**
 * @ORM\Entity(repositoryClass=ProductsRepository::class)
 */
class Products
{
    public function __construct()
    {
        $this->name="Microwave";
        $this->price=300;
        $this->category="AGD";
        $this->quantity=10;
        $this->soldOut=false;
        $this->currency="pln";
        $this->discount=true;
        $this->discountPercent=0.5;
        $this->priceAfterDiscount=150;
        $this->description="Simply use and gorgeous design.";


        /**$this->setName("Microwave");
        $this->setPrice(300);
        $this->setCategory("AGD");
        $this->setQuantity(10);
        $this->setSoldOut(false);
        $this->setCurrency("pln");
        $this->setDiscount(true);
        $this->setDiscountPercent(0.5);
        $this->setPriceAfterDiscount(150);
        $this->setDescription("Simply use and gorgeous design.");
*/
    }

    /**
     * @ORM\Id()
     * @ORM\GeneratedValue()
     * @ORM\Column(type="integer")
     */
    private $id;

    /**
     * @ORM\Column(type="string", length=255)
     */
    private $name;

    /**
     * @ORM\Column(type="float")
     */
    private $price;

    /**
     * @ORM\Column(type="string", length=255)
     */
    private $category;

    /**
     * @ORM\Column(type="integer")
     */
    private $quantity;

    /**
     * @ORM\Column(type="boolean")
     */
    private $soldOut;

    /**
     * @ORM\Column(type="string", length=255)
     */
    private $currency;

    /**
     * @ORM\Column(type="boolean")
     */
    private $discount;

    /**
     * @ORM\Column(type="float")
     */
    private $discountPercent;

    /**
     * @ORM\Column(type="float")
     */
    private $priceAfterDiscount;

    /**
     * @ORM\Column(type="string", length=255)
     */
    private $description;

    public function getId(): ?int
    {
        return $this->id;
    }

    public function getName(): ?string
    {
        return $this->name;
    }

    public function setName(string $name): self
    {
        $this->name = $name;

        return $this;
    }

    public function getPrice(): ?int
    {
        return $this->price;
    }

    public function setPrice(int $price): self
    {
        $this->price = $price;

        return $this;
    }

    public function getCategory(): ?string
    {
        return $this->category;
    }

    public function setCategory(string $category): self
    {
        $this->category = $category;

        return $this;
    }

    public function getQuantity(): ?int
    {
        return $this->quantity;
    }

    public function setQuantity(int $quantity): self
    {
        $this->quantity = $quantity;

        return $this;
    }

    public function getSoldOut(): ?bool
    {
        return $this->soldOut;
    }

    public function setSoldOut(bool $soldOut): self
    {
        $this->soldOut = $soldOut;

        return $this;
    }

    public function getCurrency(): ?string
    {
        return $this->currency;
    }

    public function setCurrency(string $currency): self
    {
        $this->currency = $currency;

        return $this;
    }

    public function getDiscount(): ?bool
    {
        return $this->discount;
    }

    public function setDiscount(bool $discount): self
    {
        $this->discount = $discount;

        return $this;
    }

    public function getDiscountPercent(): ?float
    {
        return $this->discountPercent;
    }

    public function setDiscountPercent(float $discountPercent): self
    {
        $this->discountPercent = $discountPercent;

        return $this;
    }

    public function getPriceAfterDiscount(): ?float
    {
        return $this->priceAfterDiscount;
    }

    public function setPriceAfterDiscount(float $priceAfterDiscount): self
    {
        $this->priceAfterDiscount = $priceAfterDiscount;

        return $this;
    }

    public function getDescription(): ?string
    {
        return $this->description;
    }

    public function setDescription(string $description): self
    {
        $this->description = $description;

        return $this;
    }
}
